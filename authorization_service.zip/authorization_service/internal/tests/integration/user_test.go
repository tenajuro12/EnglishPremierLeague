package integration_test

import (
	"context"
	"testing"

	"authorization_service/internal/entity"
	"authorization_service/internal/repository"
	"authorization_service/internal/usecase/webapi"
	"authorization_service/pkg/db"
	"authorization_service/pkg/logger"

	"github.com/stretchr/testify/assert"
)

func TestUserIntegration(t *testing.T) {
	log := logger.NewLogger(logger.LoggerConfig{
		Level: "info",
	})

	// database
	dbpool, err := db.NewPostgresDB("postgres://postgres:mansur@localhost/epl_db?sslmode=disable")
	if err != nil {
		log.Fatalf("Failed to connect to database: %v", err)
	}
	defer dbpool.Close()

	userRepo := repository.NewUserRepository(dbpool)

	userUsecase := webapi.NewUserUsecase(userRepo)

	ctx := context.Background()
	user := entity.User{
		Username: "tester",
		Password: "testpass",
		Email:    "test@gmail.com",
	}
	err = userUsecase.Register(ctx, user)
	assert.NoError(t, err, "error registering user")

	user.Email = "updated@example.com"
	err = userUsecase.UpdateUser(ctx, user)
	assert.NoError(t, err, "error updating user")

	updatedUser, err := userUsecase.GetUserByID(ctx, user.ID)
	assert.NoError(t, err, "error getting user by ID")
	assert.Equal(t, user.Email, updatedUser.Email, "updated email should match")

	err = userUsecase.DeleteUser(ctx, user.ID)
	assert.NoError(t, err, "error deleting user")
}
