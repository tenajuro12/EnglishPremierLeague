package main

import (
	"context"
	"log"
	"net"

	"authorization_service/internal/entity"
	"authorization_service/internal/repository"

	"authorization_service/internal/usecase/webapi"

	pb "authorization_service/internal/proto"

	"github.com/jackc/pgx/v4/pgxpool"
	"google.golang.org/grpc"
)

type server struct {
	pb.UnimplementedAuthorizationServiceServer
	userUsecase  webapi.UserUsecase
	adminUsecase webapi.AdminUsecase
}

func main() {
	dbpool, err := pgxpool.Connect(context.Background(), "postgres://postgres:mansur@localhost/epl_db?sslmode=disable")
	if err != nil {
		log.Fatal(err)
	}
	defer dbpool.Close()

	userRepo := repository.NewUserRepository(dbpool)
	adminRepo := repository.NewAdminRepository(dbpool)

	userUsecase := webapi.NewUserUsecase(userRepo)
	adminUsecase := webapi.NewAdminUsecase(adminRepo)

	lis, err := net.Listen("tcp", ":50050")
	if err != nil {
		log.Fatalf("failed to listen: %v", err)
	}

	grpcServer := grpc.NewServer()
	pb.RegisterAuthorizationServiceServer(grpcServer, &server{
		userUsecase:  userUsecase,
		adminUsecase: adminUsecase,
	})

	log.Println("Starting gRPC server on :50050")
	if err := grpcServer.Serve(lis); err != nil {
		log.Fatalf("failed to serve: %v", err)
	}
}

func (s *server) RegisterUser(ctx context.Context, req *pb.RegisterUserRequest) (*pb.RegisterUserResponse, error) {
	user := entity.User{
		Username: req.GetUsername(),
		Password: req.GetPassword(),
		Email:    req.GetEmail(),
	}

	err := s.userUsecase.Register(ctx, user)
	if err != nil {
		return nil, err
	}

	return &pb.RegisterUserResponse{Id: int32(user.ID)}, nil
}

func (s *server) LoginUser(ctx context.Context, req *pb.LoginUserRequest) (*pb.LoginUserResponse, error) {
	user, err := s.userUsecase.Login(ctx, req.GetUsername(), req.GetPassword())
	if err != nil {
		return nil, err
	}

	return &pb.LoginUserResponse{User: &pb.User{
		Id:       int32(user.ID),
		Username: user.Username,
		Password: user.Password,
		Email:    user.Email,
	}}, nil
}

func (s *server) GetUserByID(ctx context.Context, req *pb.GetUserByIDRequest) (*pb.GetUserByIDResponse, error) {
	user, err := s.userUsecase.GetUserByID(ctx, int(req.GetId()))
	if err != nil {
		return nil, err
	}

	return &pb.GetUserByIDResponse{User: &pb.User{
		Id:       int32(user.ID),
		Username: user.Username,
		Password: user.Password,
		Email:    user.Email,
	}}, nil
}

func (s *server) UpdateUser(ctx context.Context, req *pb.UpdateUserRequest) (*pb.UpdateUserResponse, error) {
	user := entity.User{
		ID:       int(req.GetId()),
		Username: req.GetUsername(),
		Password: req.GetPassword(),
		Email:    req.GetEmail(),
	}

	err := s.userUsecase.UpdateUser(ctx, user)
	if err != nil {
		return nil, err
	}

	return &pb.UpdateUserResponse{User: &pb.User{
		Id:       int32(user.ID),
		Username: user.Username,
		Password: user.Password,
		Email:    user.Email,
	}}, nil
}

func (s *server) DeleteUser(ctx context.Context, req *pb.DeleteUserRequest) (*pb.DeleteUserResponse, error) {
	err := s.userUsecase.DeleteUser(ctx, int(req.GetId()))
	if err != nil {
		return nil, err
	}
	return &pb.DeleteUserResponse{}, nil
}

func (s *server) FilterUsers(ctx context.Context, req *pb.FilterUsersRequest) (*pb.FilterUsersResponse, error) {
	users, err := s.userUsecase.FilterUsers(ctx, req.GetUsername(), req.GetEmail())
	if err != nil {
		return nil, err
	}

	var pbUsers []*pb.User
	for _, user := range users {
		pbUser := &pb.User{
			Id:       int32(user.ID),
			Username: user.Username,
			Password: user.Password,
			Email:    user.Email,
		}
		pbUsers = append(pbUsers, pbUser)
	}

	return &pb.FilterUsersResponse{Users: pbUsers}, nil
}

// Admin methods follow the same pattern as user methods

func (s *server) RegisterAdmin(ctx context.Context, req *pb.RegisterAdminRequest) (*pb.RegisterAdminResponse, error) {
	admin := entity.Admin{
		Username: req.GetUsername(),
		Password: req.GetPassword(),
		Email:    req.GetEmail(),
	}

	err := s.adminUsecase.Register(ctx, admin)
	if err != nil {
		return nil, err
	}

	return &pb.RegisterAdminResponse{Id: int32(admin.ID)}, nil
}

func (s *server) LoginAdmin(ctx context.Context, req *pb.LoginAdminRequest) (*pb.LoginAdminResponse, error) {
	admin, err := s.adminUsecase.Login(ctx, req.GetUsername(), req.GetPassword())
	if err != nil {
		return nil, err
	}

	return &pb.LoginAdminResponse{Admin: &pb.Admin{
		Id:       int32(admin.ID),
		Username: admin.Username,
		Password: admin.Password,
		Email:    admin.Email,
	}}, nil
}
