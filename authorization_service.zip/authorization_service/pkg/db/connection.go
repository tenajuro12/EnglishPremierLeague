package db

import (
	"context"
	"github.com/jackc/pgx/v4/pgxpool"
)

func NewPostgresDB(cfg string) (*pgxpool.Pool, error) {
	poolConfig, err := pgxpool.ParseConfig(cfg)
	if err != nil {
		return nil, err
	}

	dbpool, err := pgxpool.ConnectConfig(context.Background(), poolConfig)
	if err != nil {
		return nil, err
	}

	return dbpool, nil
}
