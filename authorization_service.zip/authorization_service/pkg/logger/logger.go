package logger

import (
	"github.com/sirupsen/logrus"
)

type Logger struct {
	*logrus.Logger
}

func NewLogger(config LoggerConfig) *Logger {
	log := logrus.New()

	level, err := logrus.ParseLevel(config.Level)
	if err != nil {
		log.Fatalf("Invalid log level: %v", err)
	}
	log.SetLevel(level)

	return &Logger{log}
}

type LoggerConfig struct {
	Level string
}
