DROP TABLE IF EXISTS news_articles;
