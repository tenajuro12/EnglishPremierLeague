package unit

import (
	"authorization_service/internal/entity"
	"authorization_service/internal/repository"
	"context"
	"github.com/DATA-DOG/go-sqlmock"
	"github.com/jackc/pgx/v4/pgxpool"
	"github.com/stretchr/testify/assert"
	"testing"
)

func setupMockDB(t *testing.T) (*pgxpool.Pool, sqlmock.Sqlmock, func()) {
	mockDB, mock, err := sqlmock.New()
	if err != nil {
		t.Fatalf("Failed to open sqlmock database connection: %v", err)
	}

	pgxpool, err := pgxpool.Connect(context.Background(), "postgres://postgres:mansur@localhost/epl_db?sslmode=disable")
	if err != nil {
		t.Fatalf("Failed to create pgxpool: %v", err)
	}

	cleanup := func() {
		mockDB.Close()
	}
	return pgxpool, mock, cleanup
}

func TestCreateAdmin(t *testing.T) {
	pgxpool, mock, cleanup := setupMockDB(t)
	defer cleanup()

	repo := repository.NewAdminRepository(pgxpool)

	admin := entity.Admin{
		Username: "testUser",
		Password: "testPassword",
		Email:    "test@example.com",
	}

	query := `INSERT INTO admins \(username, password, email\) VALUES \(\$1, \$2, \$3\)`

	mock.ExpectExec(query).
		WithArgs(admin.Username, admin.Password, admin.Email).
		WillReturnResult(sqlmock.NewResult(1, 1))

	err := repo.CreateAdmin(context.Background(), admin)
	assert.NoError(t, err)

	err = mock.ExpectationsWereMet()
	assert.NoError(t, err)
}

func TestGetAdminByID(t *testing.T) {
	db, mock, cleanup := setupMockDB(t)
	defer cleanup()

	repo := repository.NewAdminRepository(db)

	adminID := 1
	expectedAdmin := entity.Admin{
		ID:       adminID,
		Username: "testadmin",
		Password: "password",
		Email:    "test@example.com",
	}

	query := `SELECT id, username, password, email FROM admins WHERE id = \$1`

	mock.ExpectQuery(query).
		WithArgs(adminID).
		WillReturnRows(sqlmock.NewRows([]string{"id", "username", "password", "email"}).
			AddRow(expectedAdmin.ID, expectedAdmin.Username, expectedAdmin.Password, expectedAdmin.Email))

	result, err := repo.GetAdminByID(context.Background(), adminID)
	assert.NoError(t, err)
	assert.Equal(t, expectedAdmin, result)

	err = mock.ExpectationsWereMet()
	assert.NoError(t, err)
}

func TestUpdateAdmin(t *testing.T) {
	db, mock, cleanup := setupMockDB(t)
	defer cleanup()

	repo := repository.NewAdminRepository(db)

	admin := entity.Admin{
		ID:       1,
		Username: "updatedAdmin",
		Password: "updatedPassword",
		Email:    "updated@example.com",
	}

	query := `UPDATE admins SET username = \$1, password = \$2, email = \$3 WHERE id = \$4`

	mock.ExpectExec(query).
		WithArgs(admin.Username, admin.Password, admin.Email, admin.ID).
		WillReturnResult(sqlmock.NewResult(1, 1))

	err := repo.UpdateAdmin(context.Background(), admin)
	assert.NoError(t, err)

	err = mock.ExpectationsWereMet()
	assert.NoError(t, err)
}

func TestDeleteAdmin(t *testing.T) {
	db, mock, cleanup := setupMockDB(t)
	defer cleanup()

	repo := repository.NewAdminRepository(db)

	adminID := 1

	query := `DELETE FROM admins WHERE id = \$1`

	mock.ExpectExec(query).
		WithArgs(adminID).
		WillReturnResult(sqlmock.NewResult(0, 1))

	err := repo.DeleteAdmin(context.Background(), adminID)
	assert.NoError(t, err)

	err = mock.ExpectationsWereMet()
	assert.NoError(t, err)
}

func TestGetAdminByUsername(t *testing.T) {
	db, mock, cleanup := setupMockDB(t)
	defer cleanup()

	repo := repository.NewAdminRepository(db)

	expectedAdmin := entity.Admin{
		ID:       1,
		Username: "testadmin",
		Password: "password",
		Email:    "test@example.com",
	}

	query := `SELECT id, username, password, email FROM admins WHERE username = \$1`

	mock.ExpectQuery(query).
		WithArgs(expectedAdmin.Username).
		WillReturnRows(sqlmock.NewRows([]string{"id", "username", "password", "email"}).
			AddRow(expectedAdmin.ID, expectedAdmin.Username, expectedAdmin.Password, expectedAdmin.Email))

	result, err := repo.GetAdminByUsername(context.Background(), expectedAdmin.Username)
	assert.NoError(t, err)
	assert.Equal(t, expectedAdmin, result)

	err = mock.ExpectationsWereMet()
	assert.NoError(t, err)
}
