package unit

import (
	"authorization_service/internal/entity"
	"authorization_service/internal/usecase/webapi"
	"context"
	"github.com/pkg/errors"
	"testing"
)

type mockUserRepository struct{}

func (m *mockUserRepository) GetUserByID(ctx context.Context, id int) (entity.User, error) {
	if id == 1 {
		return entity.User{
			ID:       1,
			Username: "user1",
			Email:    "user1@example.com",
		}, nil
	}
	return entity.User{}, errors.New("user not found")
}
func (m *mockUserRepository) FilterUsers(ctx context.Context, username, email string) ([]entity.User, error) {
	return []entity.User{
		{ID: 1, Username: "user1", Email: "user1@example.com"},
		{ID: 2, Username: "user2", Email: "user2@example.com"},
	}, nil
}

func (m *mockUserRepository) CreateUser(ctx context.Context, user entity.User) error {
	return nil
}

func (m *mockUserRepository) UpdateUser(ctx context.Context, user entity.User) error {
	return nil
}

func (m *mockUserRepository) DeleteUser(ctx context.Context, id int) error {
	return nil
}

func (m *mockUserRepository) GetUserByUsername(ctx context.Context, username string) (entity.User, error) {
	return entity.User{}, nil
}

func TestUserUsecase_Register(t *testing.T) {
	mockRepo := &mockUserRepository{}
	userUsecase := webapi.NewUserUsecase(mockRepo)

	err := userUsecase.Register(context.Background(), entity.User{
		Username: "existing_username",
		Password: "password",
		Email:    "email@example.com",
	})

	expectedErr := errors.New("username already exists")
	if err.Error() != expectedErr.Error() {
		t.Errorf("Expected error: %v, but got: %v", expectedErr, err)
	}
}
func TestFilterUsers(t *testing.T) {
	mockRepo := &mockUserRepository{}
	usecase := webapi.NewUserUsecase(mockRepo)

	username := "testUsername"
	email := "testEmail"

	users, err := usecase.FilterUsers(context.Background(), username, email)
	if err != nil {
		t.Errorf("expected no error, got %v", err)
	}

	expectedCount := 2
	if len(users) != expectedCount {
		t.Errorf("expected %d users, got %d", expectedCount, len(users))
	}
}
