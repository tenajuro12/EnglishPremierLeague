package unit_test

import (
	"context"
	"errors"
	"testing"

	"authorization_service/internal/entity"
	"authorization_service/internal/repository"
	"authorization_service/internal/usecase/webapi"
)

type MockAdminRepository struct {
	admins                 map[int]entity.Admin
	GetAdminByUsernameFunc func(ctx context.Context, username string) (entity.Admin, error)
}

func (m *MockAdminRepository) FilterAdmins(ctx context.Context, username, email, sortBy string, offset, limit int) ([]entity.Admin, error) {
	//TODO implement me
	panic("implement me")
}

func NewMockAdminRepository() repository.AdminRepository {
	return &MockAdminRepository{
		admins: make(map[int]entity.Admin),
	}
}

func (m *MockAdminRepository) CreateAdmin(ctx context.Context, admin entity.Admin) error {
	m.admins[admin.ID] = admin
	return nil
}

func (m *MockAdminRepository) DeleteAdmin(ctx context.Context, adminID int) error {
	if _, ok := m.admins[adminID]; !ok {
		return errors.New("admin not found")
	}
	delete(m.admins, adminID)
	return nil
}

func (m *MockAdminRepository) GetAdminByID(ctx context.Context, adminID int) (entity.Admin, error) {
	admin, ok := m.admins[adminID]
	if !ok {
		return entity.Admin{}, errors.New("admin not found")
	}
	return admin, nil
}

func (m *MockAdminRepository) UpdateAdmin(ctx context.Context, admin entity.Admin) error {
	if _, ok := m.admins[admin.ID]; !ok {
		return errors.New("admin not found")
	}
	m.admins[admin.ID] = admin
	return nil
}

func (m *MockAdminRepository) GetAdminByUsername(ctx context.Context, username string) (entity.Admin, error) {
	if m.GetAdminByUsernameFunc != nil {
		return m.GetAdminByUsernameFunc(ctx, username)
	}
	return entity.Admin{}, errors.New("admin not found")
}

func TestRegisterAdmin(t *testing.T) {
	repo := NewMockAdminRepository()
	usecase := webapi.NewAdminUsecase(repo)

	admin := entity.Admin{
		ID:       1,
		Username: "testUser",
		Password: "testPassword",
		Email:    "test@example.com",
	}

	mockRepo := repo.(*MockAdminRepository)
	mockRepo.GetAdminByUsernameFunc = func(ctx context.Context, username string) (entity.Admin, error) {
		return entity.Admin{}, nil
	}

	err := usecase.Register(context.Background(), admin)
	if err != nil {
		t.Errorf("expected no error, got %v", err)
	}

	err = usecase.Register(context.Background(), admin)
	expectedErr := errors.New("admin already exists")
	if err.Error() != expectedErr.Error() {
		t.Errorf("expected error: %v, got: %v", expectedErr, err)
	}

	registeredAdmin, err := repo.GetAdminByUsername(context.Background(), admin.Username)
	if err != nil {
		t.Errorf("expected no error, got %v", err)
	}

	if registeredAdmin.ID != admin.ID || registeredAdmin.Username != admin.Username {
		t.Errorf("admin data does not match expected values")
	}
}

func TestUpdateAdmin(t *testing.T) {
	repo := &MockAdminRepository{
		admins: map[int]entity.Admin{
			1: {ID: 1, Username: "admin1", Password: "password1", Email: "admin1@example.com"},
			2: {ID: 2, Username: "admin2", Password: "password2", Email: "admin2@example.com"},
		},
	}

	usecase := webapi.NewAdminUsecase(repo)

	admin := entity.Admin{
		ID:       1,
		Username: "updated_admin",
		Password: "updated_password",
		Email:    "updated_admin@example.com",
	}

	err := usecase.UpdateAdmin(context.Background(), admin)

	if err != nil {
		t.Errorf("unexpected error: %v", err)
	}

	updatedAdmin, ok := repo.admins[admin.ID]
	if !ok {
		t.Error("admin not found in repository after update")
	}

	if updatedAdmin.Username != admin.Username || updatedAdmin.Password != admin.Password || updatedAdmin.Email != admin.Email {
		t.Error("updated data does not match expected values")
	}
}

func TestLogin(t *testing.T) {
	repo := NewMockAdminRepository()
	usecase := webapi.NewAdminUsecase(repo)

	admin := entity.Admin{
		Username: "testUser",
		Password: "testPassword",
	}

	mockRepo := repo.(*MockAdminRepository)
	mockRepo.GetAdminByUsernameFunc = func(ctx context.Context, username string) (entity.Admin, error) {
		if username != admin.Username {
			return entity.Admin{}, errors.New("admin not found")
		}
		return admin, nil
	}

	result, err := usecase.Login(context.Background(), admin.Username, admin.Password)
	if err != nil {
		t.Errorf("expected no error, got %v", err)
	}

	if result.Username != admin.Username {
		t.Errorf("expected username %s, got %s", admin.Username, result.Username)
	}
}

func TestDeleteAdmin(t *testing.T) {
	repo := &MockAdminRepository{
		admins: map[int]entity.Admin{
			1: {ID: 1, Username: "admin1", Password: "password1", Email: "admin1@example.com"},
			2: {ID: 2, Username: "admin2", Password: "password2", Email: "admin2@example.com"},
		},
	}

	usecase := webapi.NewAdminUsecase(repo)

	err := usecase.DeleteAdmin(context.Background(), 1)
	if err != nil {
		t.Errorf("expected no error, got %v", err)
	}

	err = usecase.DeleteAdmin(context.Background(), 3)
	expectedErr := errors.New("admin not found")
	if err.Error() != expectedErr.Error() {
		t.Errorf("expected error: %v, but got: %v", expectedErr, err)
	}
}
