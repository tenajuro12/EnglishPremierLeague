package webapi

import (
	"authorization_service/internal/entity"
	"authorization_service/internal/repository"
	"context"
	"errors"
)

type AdminUsecase interface {
	Register(ctx context.Context, admin entity.Admin) error
	Login(ctx context.Context, username, password string) (entity.Admin, error)
	GetAdminByID(ctx context.Context, id int) (entity.Admin, error)
	UpdateAdmin(ctx context.Context, admin entity.Admin) error
	DeleteAdmin(ctx context.Context, id int) error
}

type adminUsecase struct {
	adminRepo repository.AdminRepository
}

func NewAdminUsecase(adminRepo repository.AdminRepository) AdminUsecase {
	return &adminUsecase{adminRepo: adminRepo}
}

func (u *adminUsecase) Register(ctx context.Context, admin entity.Admin) error {
	_, err := u.adminRepo.GetAdminByUsername(ctx, admin.Username)
	if err == nil {
		return errors.New("username already exists")
	}
	return u.adminRepo.CreateAdmin(ctx, admin)
}

func (u *adminUsecase) Login(ctx context.Context, username, password string) (entity.Admin, error) {
	admin, err := u.adminRepo.GetAdminByUsername(ctx, username)
	if err != nil || admin.Password != password {
		return entity.Admin{}, errors.New("invalid username or password")
	}
	return admin, nil
}

func (u *adminUsecase) GetAdminByID(ctx context.Context, id int) (entity.Admin, error) {
	return u.adminRepo.GetAdminByID(ctx, id)
}

func (u *adminUsecase) UpdateAdmin(ctx context.Context, admin entity.Admin) error {
	return u.adminRepo.UpdateAdmin(ctx, admin)
}

func (u *adminUsecase) DeleteAdmin(ctx context.Context, id int) error {
	return u.adminRepo.DeleteAdmin(ctx, id)
}
