package webapi

import (
	"authorization_service/internal/entity"
	"authorization_service/internal/repository"
	"context"
	"errors"
)

type UserUsecase interface {
	Register(ctx context.Context, user entity.User) error
	Login(ctx context.Context, username, password string) (entity.User, error)
	GetUserByID(ctx context.Context, id int) (entity.User, error)
	UpdateUser(ctx context.Context, user entity.User) error
	DeleteUser(ctx context.Context, id int) error
	FilterUsers(ctx context.Context, username, email string) ([]entity.User, error)
}

type userUsecase struct {
	userRepo repository.UserRepository
}

func (u *userUsecase) FilterUsers(ctx context.Context, username, email string) ([]entity.User, error) {
	users, err := u.userRepo.FilterUsers(ctx, username, email)
	if err != nil {
		return nil, err
	}
	return users, nil
}

func NewUserUsecase(userRepo repository.UserRepository) UserUsecase {
	return &userUsecase{userRepo: userRepo}
}

func (u *userUsecase) Register(ctx context.Context, user entity.User) error {
	_, err := u.userRepo.GetUserByUsername(ctx, user.Username)
	if err == nil {
		return errors.New("username already exists")
	}
	return u.userRepo.CreateUser(ctx, user)
}

func (u *userUsecase) Login(ctx context.Context, username, password string) (entity.User, error) {
	user, err := u.userRepo.GetUserByUsername(ctx, username)
	if err != nil || user.Password != password {
		return entity.User{}, errors.New("invalid username or password")
	}
	return user, nil
}

func (u *userUsecase) GetUserByID(ctx context.Context, id int) (entity.User, error) {
	return u.userRepo.GetUserByID(ctx, id)
}

func (u *userUsecase) UpdateUser(ctx context.Context, user entity.User) error {
	return u.userRepo.UpdateUser(ctx, user)
}

func (u *userUsecase) DeleteUser(ctx context.Context, id int) error {
	return u.userRepo.DeleteUser(ctx, id)
}
