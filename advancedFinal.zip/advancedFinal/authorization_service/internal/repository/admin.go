package repository

import (
	"authorization_service/internal/entity"
	"context"
	"errors"
	"github.com/jackc/pgx/v4"
	"github.com/jackc/pgx/v4/pgxpool"
)

type AdminRepository interface {
	CreateAdmin(ctx context.Context, admin entity.Admin) error
	GetAdminByUsername(ctx context.Context, username string) (entity.Admin, error)
	GetAdminByID(ctx context.Context, id int) (entity.Admin, error)
	UpdateAdmin(ctx context.Context, admin entity.Admin) error
	DeleteAdmin(ctx context.Context, id int) error
}

type adminRepository struct {
	db *pgxpool.Pool
}

func NewAdminRepository(db *pgxpool.Pool) AdminRepository {
	return &adminRepository{db: db}
}

func (r *adminRepository) CreateAdmin(ctx context.Context, admin entity.Admin) error {
	query := `INSERT INTO admins (username, password, email) VALUES ($1, $2, $3)`
	_, err := r.db.Exec(ctx, query, admin.Username, admin.Password, admin.Email)
	if err != nil {
		return err
	}
	return nil
}

func (r *adminRepository) GetAdminByUsername(ctx context.Context, username string) (entity.Admin, error) {
	var admin entity.Admin
	query := `SELECT id, username, password, email FROM admins WHERE username = $1`
	err := r.db.QueryRow(ctx, query, username).Scan(&admin.ID, &admin.Username, &admin.Password, &admin.Email)
	if err != nil {
		if err == pgx.ErrNoRows {
			return admin, errors.New("admin not found")
		}
		return admin, err
	}
	return admin, nil
}

func (r *adminRepository) GetAdminByID(ctx context.Context, id int) (entity.Admin, error) {
	var admin entity.Admin
	query := `SELECT id, username, password, email FROM admins WHERE id = $1`
	err := r.db.QueryRow(ctx, query, id).Scan(&admin.ID, &admin.Username, &admin.Password, &admin.Email)
	if err != nil {
		if err == pgx.ErrNoRows {
			return admin, errors.New("admin not found")
		}
		return admin, err
	}
	return admin, nil
}

func (r *adminRepository) UpdateAdmin(ctx context.Context, admin entity.Admin) error {
	query := `UPDATE admins SET username = $1, password = $2, email = $3 WHERE id = $4`
	_, err := r.db.Exec(ctx, query, admin.Username, admin.Password, admin.Email, admin.ID)
	if err != nil {
		return err
	}
	return nil
}

func (r *adminRepository) DeleteAdmin(ctx context.Context, id int) error {
	query := `DELETE FROM admins WHERE id = $1`
	_, err := r.db.Exec(ctx, query, id)
	if err != nil {
		return err
	}
	return nil
}
