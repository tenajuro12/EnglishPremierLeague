package main

import (
	"authorization_service/config"
	"authorization_service/internal/controller/http1"
	"authorization_service/internal/repository"
	"authorization_service/internal/usecase/webapi"
	"authorization_service/pkg/logger"
	"context"
	"log"
	"net/http"
	"sync"

	"github.com/gorilla/mux"
	"github.com/jackc/pgx/v4/pgxpool"
)

func main() {
	cfg := loadConfiguration()
	log := setupLogger(cfg.Logger)

	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	dbpool := setupDatabase(ctx, cfg.Database.DSN, log)
	defer dbpool.Close()

	userRepo := repository.NewUserRepository(dbpool)
	userUsecase := webapi.NewUserUsecase(userRepo)
	adminRepo := repository.NewAdminRepository(dbpool)
	adminUsecase := webapi.NewAdminUsecase(adminRepo)

	wg := sync.WaitGroup{}
	wg.Add(1)
	go startHTTPServer(&wg, cfg, userUsecase, adminUsecase, log)
	wg.Wait()
}

func loadConfiguration() *config.Config {
	cfg, err := config.LoadConfig()
	if err != nil {
		log.Fatalf("Failed to load configuration: %v", err)
	}
	return cfg
}

func setupLogger(cfg logger.LoggerConfig) *logger.Logger {
	return logger.NewLogger(cfg)
}

func setupDatabase(ctx context.Context, dsn string, log *logger.Logger) *pgxpool.Pool {
	dbpool, err := pgxpool.Connect(ctx, dsn)
	if err != nil {
		log.Fatalf("Failed to connect to database: %v", err)
	}
	return dbpool
}

func startHTTPServer(wg *sync.WaitGroup, cfg *config.Config, userUsecase webapi.UserUsecase, adminUsecase webapi.AdminUsecase, log *logger.Logger) {
	defer wg.Done()

	r := mux.NewRouter()
	setupRoutes(r, userUsecase, adminUsecase)

	srv := &http.Server{
		Addr:    cfg.Server.Address,
		Handler: r,
	}

	log.Infof("Starting HTTP server on %s", cfg.Server.Address)
	if err := srv.ListenAndServe(); err != nil {
		log.Fatalf("Failed to start HTTP server: %v", err)
	}
}

func setupRoutes(r *mux.Router, userUsecase webapi.UserUsecase, adminUsecase webapi.AdminUsecase) {
	userHandler := http1.NewUserHandler(userUsecase)
	adminHandler := http1.NewAdminHandler(adminUsecase)

	r.HandleFunc("/register", userHandler.Register).Methods(http.MethodPost)
	r.HandleFunc("/login", userHandler.Login).Methods(http.MethodPost)
	r.HandleFunc("/user/{id:[0-9]+}", userHandler.GetUser).Methods(http.MethodGet)
	r.HandleFunc("/user/{id:[0-9]+}", userHandler.UpdateUser).Methods(http.MethodPut)
	r.HandleFunc("/user/{id:[0-9]+}", userHandler.DeleteUser).Methods(http.MethodDelete)

	r.HandleFunc("/admin/register", adminHandler.Register).Methods(http.MethodPost)
	r.HandleFunc("/admin/login", adminHandler.Login).Methods(http.MethodPost)
	r.HandleFunc("/admin/{id:[0-9]+}", adminHandler.GetAdmin).Methods(http.MethodGet)
	r.HandleFunc("/admin/{id:[0-9]+}", adminHandler.UpdateAdmin).Methods(http.MethodPut)
	r.HandleFunc("/admin/{id:[0-9]+}", adminHandler.DeleteAdmin).Methods(http.MethodDelete)
}
