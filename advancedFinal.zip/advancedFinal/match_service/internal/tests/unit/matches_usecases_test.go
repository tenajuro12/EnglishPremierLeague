package unit_test

import (
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/mock"
	"match_service/internal/entity"
	"match_service/internal/usecases"
	"testing"
	"time"
)

type MockRepository struct {
	mock.Mock
}

func TestCreateMatch_Execute(t *testing.T) {
	mockRepo := new(MockRepository)
	useCase := &usecases.CreateMatch{
		Repository: mockRepo,
	}

	match := entity.NewMatch{
		HomeTeam:  "Team A",
		AwayTeam:  "Team B",
		Date:      "2024-06-01",
		Status:    "Scheduled",
		HomeScore: 0,
		AwayScore: 0,
	}

	expectedMatch := match
	expectedMatch.ID = 1
	expectedMatch.CreatedAt = time.Now()
	expectedMatch.UpdatedAt = time.Now()

	mockRepo.On("Insert", mock.Anything).Return(expectedMatch, nil)

	result, err := useCase.Execute(match)

	assert.NoError(t, err)
	assert.Equal(t, expectedMatch, result)
	mockRepo.AssertExpectations(t)
}

func TestDeleteMatch_Execute(t *testing.T) {
	mockRepo := new(MockRepository)
	useCase := &usecases.DeleteMatch{
		Repository: mockRepo,
	}

	mockRepo.On("Delete", 1).Return(nil)

	err := useCase.Execute(1)

	assert.NoError(t, err)
	mockRepo.AssertExpectations(t)
}

func TestFindMatchByID_Execute(t *testing.T) {
	mockRepo := new(MockRepository)
	useCase := &usecases.FindMatchByID{
		Repository: mockRepo,
	}

	expectedMatch := entity.NewMatch{
		ID:        1,
		HomeTeam:  "Team A",
		AwayTeam:  "Team B",
		Date:      "2024-06-01",
		Status:    "Scheduled",
		HomeScore: 0,
		AwayScore: 0,
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
	}

	mockRepo.On("FindByID", 1).Return(expectedMatch, nil)

	result, err := useCase.Execute(1)

	assert.NoError(t, err)
	assert.Equal(t, expectedMatch, result)
	mockRepo.AssertExpectations(t)
}

func TestFindAllMatches_Execute(t *testing.T) {
	mockRepo := new(MockRepository)
	useCase := &usecases.FindAllMatches{
		Repository: mockRepo,
	}

	match1 := entity.NewMatch{
		ID:        1,
		HomeTeam:  "Team A",
		AwayTeam:  "Team B",
		Date:      "2024-06-01",
		Status:    "Scheduled",
		HomeScore: 0,
		AwayScore: 0,
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
	}

	match2 := entity.NewMatch{
		ID:        2,
		HomeTeam:  "Team C",
		AwayTeam:  "Team D",
		Date:      "2024-06-02",
		Status:    "Scheduled",
		HomeScore: 0,
		AwayScore: 0,
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
	}

	expectedMatches := []entity.NewMatch{match1, match2}

	mockRepo.On("GetAll").Return(expectedMatches, nil)

	results, err := useCase.Execute()

	assert.NoError(t, err)
	assert.Equal(t, expectedMatches, results)
	mockRepo.AssertExpectations(t)
}

func TestUpdateMatch_Execute(t *testing.T) {
	mockRepo := new(MockRepository)
	useCase := &usecases.UpdateMatch{
		Repository: mockRepo,
	}

	match := entity.NewMatch{
		ID:        1,
		HomeTeam:  "Team A",
		AwayTeam:  "Team B",
		Date:      "2024-06-01",
		Status:    "Scheduled",
		HomeScore: 0,
		AwayScore: 0,
	}

	updatedMatch := match
	updatedMatch.Status = "Completed"
	updatedMatch.UpdatedAt = time.Now()

	mockRepo.On("Update", mock.Anything).Return(updatedMatch, nil)

	result, err := useCase.Execute(match)

	assert.NoError(t, err)
	assert.Equal(t, updatedMatch, result)
	mockRepo.AssertExpectations(t)
}

func (m *MockRepository) Insert(match entity.NewMatch) (entity.NewMatch, error) {
	args := m.Called(match)
	return args.Get(0).(entity.NewMatch), args.Error(1)
}

func (m *MockRepository) Delete(id int) error {
	args := m.Called(id)
	return args.Error(0)
}

func (m *MockRepository) FindByID(id int) (entity.NewMatch, error) {
	args := m.Called(id)
	return args.Get(0).(entity.NewMatch), args.Error(1)
}

func (m *MockRepository) GetAll() ([]entity.NewMatch, error) {
	args := m.Called()
	return args.Get(0).([]entity.NewMatch), args.Error(1)
}

func (m *MockRepository) Update(match entity.NewMatch) (entity.NewMatch, error) {
	args := m.Called(match)
	return args.Get(0).(entity.NewMatch), args.Error(1)
}
