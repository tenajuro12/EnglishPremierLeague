package main

import (
	"context"
	"database/sql"
	"log"
	"net"
	"sort"
	"time"

	"match_service/internal/entity"
	"match_service/match_service/proto"

	_ "github.com/lib/pq"

	"google.golang.org/grpc"
	"google.golang.org/protobuf/types/known/timestamppb"

	"match_service/internal/interfaces/repository"
	"match_service/internal/usecases"
)

type matchServiceServer struct {
	proto.UnimplementedMatchServiceServer
	createUseCase *usecases.CreateMatch
	getUseCase    *usecases.FindMatchByID
	updateUseCase *usecases.UpdateMatch
	deleteUseCase *usecases.DeleteMatch
	listUseCase   *usecases.FindAllMatches
}

func (s *matchServiceServer) CreateMatch(ctx context.Context, req *proto.CreateMatchRequest) (*proto.CreateMatchResponse, error) {
	match := entity.NewMatch{
		HomeTeam:  req.HomeTeam,
		AwayTeam:  req.AwayTeam,
		Date:      req.Date,
		Status:    req.Status,
		HomeScore: int(req.HomeScore),
		AwayScore: int(req.AwayScore),
		CreatedAt: time.Now(),
		UpdatedAt: time.Now(),
	}

	createdMatch, err := s.createUseCase.Execute(match)
	if err != nil {
		return nil, err
	}

	return &proto.CreateMatchResponse{
		Id:        int32(createdMatch.ID),
		HomeTeam:  createdMatch.HomeTeam,
		AwayTeam:  createdMatch.AwayTeam,
		Date:      createdMatch.Date,
		Status:    createdMatch.Status,
		HomeScore: int32(createdMatch.HomeScore),
		AwayScore: int32(createdMatch.AwayScore),
		CreatedAt: timestamppb.New(createdMatch.CreatedAt),
	}, nil
}

func (s *matchServiceServer) GetMatch(ctx context.Context, req *proto.GetMatchRequest) (*proto.GetMatchResponse, error) {
	match, err := s.getUseCase.Execute(int(req.Id))
	if err != nil {
		return nil, err
	}

	return &proto.GetMatchResponse{
		Id:        int32(match.ID),
		HomeTeam:  match.HomeTeam,
		AwayTeam:  match.AwayTeam,
		Date:      match.Date,
		Status:    match.Status,
		HomeScore: int32(match.HomeScore),
		AwayScore: int32(match.AwayScore),
		CreatedAt: timestamppb.New(match.CreatedAt),
		UpdatedAt: timestamppb.New(match.UpdatedAt),
	}, nil
}

func (s *matchServiceServer) UpdateMatch(ctx context.Context, req *proto.UpdateMatchRequest) (*proto.UpdateMatchResponse, error) {
	match := entity.NewMatch{
		ID:        int(req.Id),
		HomeTeam:  req.HomeTeam,
		AwayTeam:  req.AwayTeam,
		Date:      req.Date,
		Status:    req.Status,
		HomeScore: int(req.HomeScore),
		AwayScore: int(req.AwayScore),
		UpdatedAt: time.Now(),
	}

	updatedMatch, err := s.updateUseCase.Execute(match)
	if err != nil {
		return nil, err
	}

	return &proto.UpdateMatchResponse{
		Id:        int32(updatedMatch.ID),
		HomeTeam:  updatedMatch.HomeTeam,
		AwayTeam:  updatedMatch.AwayTeam,
		Date:      updatedMatch.Date,
		Status:    updatedMatch.Status,
		HomeScore: int32(updatedMatch.HomeScore),
		AwayScore: int32(updatedMatch.AwayScore),
		CreatedAt: timestamppb.New(updatedMatch.CreatedAt),
		UpdatedAt: timestamppb.New(updatedMatch.UpdatedAt),
	}, nil
}

func (s *matchServiceServer) DeleteMatch(ctx context.Context, req *proto.DeleteMatchRequest) (*proto.DeleteMatchResponse, error) {
	id := int(req.Id)

	if err := s.deleteUseCase.Execute(id); err != nil {
		return nil, err
	}

	return &proto.DeleteMatchResponse{}, nil
}

func (s *matchServiceServer) ListMatches(ctx context.Context, req *proto.ListMatchesRequest) (*proto.ListMatchesResponse, error) {
	matches, err := s.listUseCase.Execute()
	if err != nil {
		return nil, err
	}

	var matchResponses []*proto.Match
	for _, match := range matches {
		matchResponses = append(matchResponses, &proto.Match{
			Id:        int32(match.ID),
			HomeTeam:  match.HomeTeam,
			AwayTeam:  match.AwayTeam,
			Date:      match.Date,
			Status:    match.Status,
			HomeScore: int32(match.HomeScore),
			AwayScore: int32(match.AwayScore),
			CreatedAt: timestamppb.New(match.CreatedAt),
			UpdatedAt: timestamppb.New(match.UpdatedAt),
		})
	}

	return &proto.ListMatchesResponse{Matches: matchResponses}, nil
}

func sortMatches(matches []*entity.NewMatch, sortBy, sortOrder string) []*entity.NewMatch {
	switch sortBy {
	case "home_team":
		sort.Slice(matches, func(i, j int) bool {
			if sortOrder == "desc" {
				return matches[i].HomeTeam > matches[j].HomeTeam
			}
			return matches[i].HomeTeam < matches[j].HomeTeam
		})
	case "away_team":
		sort.Slice(matches, func(i, j int) bool {
			if sortOrder == "desc" {
				return matches[i].AwayTeam > matches[j].AwayTeam
			}
			return matches[i].AwayTeam < matches[j].AwayTeam
		})
	case "date":
		sort.Slice(matches, func(i, j int) bool {
			date1, _ := time.Parse(time.RFC3339, matches[i].Date)
			date2, _ := time.Parse(time.RFC3339, matches[j].Date)
			if sortOrder == "desc" {
				return date1.After(date2)
			}
			return date1.Before(date2)
		})
	case "status":
		sort.Slice(matches, func(i, j int) bool {
			if sortOrder == "desc" {
				return matches[i].Status > matches[j].Status
			}
			return matches[i].Status < matches[j].Status
		})
	}

	return matches
}

func filterMatches(matches []*entity.NewMatch, filterByHomeTeam, filterByAwayTeam, filterByStatus string) []*entity.NewMatch {
	filteredMatches := make([]*entity.NewMatch, 0)
	for _, match := range matches {
		if (filterByHomeTeam == "" || match.HomeTeam == filterByHomeTeam) &&
			(filterByAwayTeam == "" || match.AwayTeam == filterByAwayTeam) &&
			(filterByStatus == "" || match.Status == filterByStatus) {
			filteredMatches = append(filteredMatches, match)
		}
	}
	return filteredMatches
}

func paginateMatches(matches []*entity.NewMatch, page, pageSize int32) []*entity.NewMatch {
	start := int((page - 1) * pageSize)
	end := int(page * pageSize)
	if start >= len(matches) {
		return []*entity.NewMatch{}
	}
	if end > len(matches) {
		end = len(matches)
	}
	return matches[start:end]
}

func main() {

	db, err := sql.Open("postgres", "postgres://postgres:123456@localhost:5433/users?sslmode=disable")
	if err != nil {
		log.Fatal(err)
	}
	defer db.Close()

	repo := repository.NewMatchRepository(db)

	createUseCase := &usecases.CreateMatch{Repository: repo}
	getUseCase := &usecases.FindMatchByID{Repository: repo}
	updateUseCase := &usecases.UpdateMatch{Repository: repo}
	deleteUseCase := &usecases.DeleteMatch{Repository: repo}
	listUseCase := &usecases.FindAllMatches{Repository: repo}

	lis, err := net.Listen("tcp", ":50051")
	if err != nil {
		log.Fatalf("failed to listen: %v", err)
	}

	grpcServer := grpc.NewServer()
	proto.RegisterMatchServiceServer(grpcServer, &matchServiceServer{
		createUseCase: createUseCase,
		getUseCase:    getUseCase,
		updateUseCase: updateUseCase,
		deleteUseCase: deleteUseCase,
		listUseCase:   listUseCase,
	})

	log.Println("Starting gRPC server on :50051")
	if err := grpcServer.Serve(lis); err != nil {
		log.Fatalf("failed to serve: %v", err)
	}
}
